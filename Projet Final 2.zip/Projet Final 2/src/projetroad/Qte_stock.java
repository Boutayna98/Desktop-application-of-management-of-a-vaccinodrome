package projetroad;

public class Qte_stock {
	
	private int qterecu;
	private int qteconsome;
	

}
