package projetroad;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
public class SujetDeVaccination {
	
	private int code;
	 
	private String nom;
	 
	private String prenom;
	 
	private  Date dh;
	 
	private String cin;
	 
	  
	 
	  
	 
	public void patient(int c,String n,String pr,Date h,String cin){
	 
	code=c;
	 
	nom=n;
	 
	prenom=pr;
	 
	@SuppressWarnings("unused")
	Date dh =h;
	
	this.cin= cin;
	 
	@SuppressWarnings("unused")
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
	 
	}
	 
	        @SuppressWarnings("null")
			public String afficher(){
	 
	System.out.println(" le nom est "+nom);
	 
	System.out.println(" le prenom est "+prenom);
	 
	System.out.println("la date de rendez-vous est"+dh);
	System.out.println(" le cin est "+cin);
	System.out.println(" le code est "+code);
	  
	Calendar cal = Calendar.getInstance();
	cal.add(Calendar.DATE, -1);
	DateFormat dateFormat = null;
	return dateFormat.format(cal.getTime());
	}
	
		
	
	public static void main(String[] args) {
		 
		
			}

	public static void remove(String string) {
		// TODO Auto-generated method stub
		
	}
}
