package projetroad;


import java.util.*;

import javax.swing.JScrollPane;
import javax.swing.JTable;


public class Test {
	   

	private static final String sujetDeVaccination = null;

	static Scanner input= new Scanner(System.in);
	 
	public static int real_length;
	 
	public static SujetDeVaccination []t;
	 
	public static Scanner lire =new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		real_length=0;
		t=new SujetDeVaccination[25];
		int rep;
		 
		do{
		 
		System.out.println("les operation disponible sont:");
		 
		System.out.println("1:pour ajout");
		 
		System.out.println("2:pour tester si le sujet est apte pour prendre le vaccin");
		 
		System.out.println("3:pour afficher le num�ro d'attente");
		 
		System.out.println("4:pour sortir");
		 
		System.out.println("entrer votre choix svp");
		 
		  
		 
		rep=saisie.lire_int();
		 
		         switch(rep){
		 
		         case 1:ajout();break;
		 
		         case 2:tester_aptitude_vaccin();break;
		 
		         case 3:affecter_num�ro_dattente ();break;
		 
		         case 4:;break;
		 
		          
		 
		         default:System.out.println("entrer un nbr entre 1 et 7");
		 
		         }
		 
		}while(rep!=7);
		 
		  
		 
		}
		 
		public static void ajout(){
		 
			SujetDeVaccination pt=new SujetDeVaccination();
		 
		t[++real_length]=pt;
		 
		}
		 
		  
		 
		
		 
		  
		
		public static void tester_aptitude_vaccin (){
			    
		     
	}
		
		public static void affecter_num�ro_dattente (){
			 	 
	        
		}
				     
            
			 
  
 
        }
		


