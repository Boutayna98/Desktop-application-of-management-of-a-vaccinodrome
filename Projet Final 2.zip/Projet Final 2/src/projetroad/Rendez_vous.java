package projetroad;

public class Rendez_vous {
	private int code;
	private String jour;
	private String heure;
	private String centrerdv;
	private int codeMedecin;
	private int codePatient;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getJour() {
		return jour;
	}

	public void setJour(String jour) {
		this.jour = jour;
	}

	public String getHeure() {
		return heure;
	}

	public void setHeure(String heure) {
		this.heure = heure;
	}
	

	public int getCodeMedecin() {
		return codeMedecin;
	}

	public void setCodeMedecin(int codeMedecin) {
		this.codeMedecin = codeMedecin;
	}

	public int getCodePatient() {
		return codePatient;
	}

	public void setCodePatient(int codePatient) {
		this.codePatient = codePatient;
	}	

	 
		
	 
	public static void main(String[] args) {
	}

}
