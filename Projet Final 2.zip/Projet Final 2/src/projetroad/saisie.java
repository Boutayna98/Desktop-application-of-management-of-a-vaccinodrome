package projetroad;


import java.util.Date;
import java.util.Scanner;
public class saisie {
	public static int lire_int(){
		 
		Scanner input =new Scanner (System.in);
		 
		int i =input.nextInt();
		 
		return(i);
		 
		}
		 
		public static String lire_string(){
		 
		Scanner input=new Scanner(System.in);
		 
		String i=input.next();
		 
		return(i);
		 
		}
		 
		public static Date lire_date(){
		 
		Scanner input=new Scanner (System.in);
		 
		int j=input.nextInt();
		 
		int m=input.nextInt();
		 
		int a=input.nextInt();
		 
		Date d=new Date();
		 
		d.setDate(a);
		 
		d.setDate(m);
		 
		d.setDate(j);
		 
		return(d);
		 
		  
		 
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
