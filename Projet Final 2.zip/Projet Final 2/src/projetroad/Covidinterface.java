package projetroad;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Covidinterface {

	JFrame f;
	JPanel p1;
	
	JLabel nomcitoyen;
	JLabel prenomcitoyen;
	JLabel agecitoyen;
	JLabel cin;
	JLabel maldie;
	
	
	
	JTextField tnom;
	JTextField tprenom;
	JTextField tage;
	JTextField tcin;
	JTextField tmal;
	
	
	JButton ajouter;
	JButton TesterPatient;
	JButton affecter;
	JButton Consul;

	JScrollPane p2;
	JTable vaccin;
	String[] row;
	String[] cols= {"Nom patient","Prenom Patient","CIN","�ge","Maladie chronique","�ge requis pour se faire vacciner","Num�ro d'attente","Aptitufe � faire vaccin"};
	
	
	
	public Covidinterface() {
		f= new JFrame("Gestion de rendez-vous");
		
		p1=new JPanel(new GridBagLayout());
		p1.setBackground(new Color (240, 255, 255));
		p1.setBorder(BorderFactory.createTitledBorder("Saisir les informations"));
		p1.setPreferredSize(new Dimension(100,200));
		
		
		nomcitoyen= new JLabel("Nom citoyen");
		nomcitoyen.setFont(new Font("Serif",Font.ITALIC, 15));
		prenomcitoyen= new JLabel("Prenom citoyen");
		prenomcitoyen.setFont(new Font("Serif",Font.ITALIC, 15));
		agecitoyen= new JLabel("Age citoyen");
		agecitoyen.setFont(new Font("Serif",Font.ITALIC, 15));
		cin= new JLabel("CIN");
		cin.setFont(new Font("Serif",Font.ITALIC, 15));
		
		maldie= new JLabel("Maladie chronique");
		maldie.setFont(new Font("Serif",Font.ITALIC, 15));
		
		tnom= new JTextField(20);
		tprenom= new JTextField(20);
		tage= new JTextField(20);
		tcin =new JTextField(20);
		
		
		ajouter= new JButton("Ajouter un patient(e)");
		ajouter.setFont(new Font("Arial",Font.BOLD, 10));
		TesterPatient= new JButton("�ge requis");
		TesterPatient.setFont(new Font("Arial",Font.BOLD, 10));
		affecter =new JButton("Affecter num d'attente");
		affecter.setFont(new Font("Arial",Font.BOLD, 10));
		
		ajouter.setBackground(new Color (128, 208, 208));
		TesterPatient.setBackground(new Color (128, 208, 208));
		affecter.setBackground(new Color (128, 208, 208));
		
		Consul= new JButton("Tester aptitude vaccin");
		Consul.setFont(new Font("Arial",Font.BOLD, 10));
		Consul.setBackground(new Color (128, 208, 208));
		
		JComboBox choix = new JComboBox();
		choix.addItem("Oui");
		choix.addItem("Non");
		choix.setPreferredSize(new Dimension(100,20));
		
		
		GridBagConstraints c=new GridBagConstraints();
		
		c.gridx=0;
		c.gridy=0;
		p1.add(nomcitoyen,c);
		
		c.gridx=0;
		c.gridy=2;
		p1.add(prenomcitoyen,c);
		
		c.gridx=0;
		c.gridy=4;
		p1.add(agecitoyen,c);
		
		c.gridx=0;
		c.gridy=6;
		p1.add(cin,c);

		
		c.gridx=2;
		c.gridy=0;
		p1.add(tnom,c);
		
		c.gridx=2;
		c.gridy=2;
		p1.add(tprenom,c);
		
		c.gridx=2;
		c.gridy=4;
		p1.add(tage,c);
		
		c.gridx=2;
		c.gridy=6;
		p1.add(tcin,c);
		
		c.gridx=14;
		c.gridy=0;
		p1.add(ajouter,c);
		
		
		c.gridx=0;
		c.gridy=8;
		p1.add(maldie,c);
		
		c.gridx=2;
		c.gridy=8;
		p1.add(choix,c);
		
	
		
		c.gridx=14;
		c.gridy=2;
		p1.add(TesterPatient,c);
		
		
		c.gridx=14;
		c.gridy=4;
		p1.add(affecter,c);
		
		
		c.gridx=14;
		c.gridy=6;
		p1.add(Consul,c);
		
		
		
		
		
		
		vaccin= new JTable();
		DefaultTableModel model= new DefaultTableModel();
		model.setColumnIdentifiers(cols);  
	    row=new String[10];	         
	    vaccin.setModel(model);
	    vaccin.setBackground(new Color(176,196,222));
	    
	    p2= new JScrollPane(vaccin);
	    p2.setPreferredSize(new Dimension(200, 600));
	    p2.setBorder(BorderFactory.createTitledBorder("Liste  des sujets"));
	    p2.setBackground(new Color(253, 233, 224));
	    
	    

	    
	   
	    	TesterPatient.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		 for(int i=0;i<vaccin.getRowCount();i++){
                     for(int j=0;j<vaccin.getRowCount();j++){ 
                    double k=Double.parseDouble(String.valueOf(vaccin.getValueAt(j,3)));
                    if (k<=18) {
                    	vaccin.setValueAt("Non",j,5);
                    	
                    }
                    else 
                    {vaccin.setValueAt("Oui",j,5);
                    }
                   
                    
        }       
	    }
	    }});
	    
	    
	    	
	    	Consul.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		 for(int i=0;i<vaccin.getRowCount();i++){
	                     for(int j=0;j<vaccin.getRowCount();j++){ 
	                    	 
if ((vaccin.getValueAt(j,5).equals("Oui"))&&(String.valueOf(vaccin.getValueAt(j,4)).equals("Non")))
						    {
	                    	vaccin.setValueAt("OUI",j,7);
	                    	}
	                       else 
	                    {
	                    	vaccin.setValueAt("Le patient ne peut pas faire le vaccin",j,7);
	                    }
	                   
	                    
	        }       
		    }
		    }});
		    		
	    
		JPanel p3;
		
		
		JTextField tnbr;
		JButton calculer;
		
		JButton maj;
		JTextField tmaj;

		p3=new JPanel(new GridBagLayout());
		p3.setBackground(new Color(233, 201, 177));
		p3.setBorder(BorderFactory.createTitledBorder("Mise � jour du stock "));
		p3.setPreferredSize(new Dimension(100,100));
		
		
		
		
		tnbr = new JTextField(10);
		calculer= new JButton("Calcul nombre de doses donn�s ");
		calculer.setFont(new Font("Arial",Font.BOLD, 10));
		
		
		maj= new JButton("Mise � jour du stock du vaccin");
		tmaj= new JTextField(10);
		maj.setFont(new Font("Arial",Font.BOLD, 10));
		
		maj.setBackground(new Color (128, 208, 208));
		calculer.setBackground(new Color (128, 208, 208));
		
		
		GridBagConstraints a=new GridBagConstraints();
		
		
		a.gridx=2;
		a.gridy=1;
		p3.add(calculer,a);
				
		
		a.gridx=2;
		a.gridy=5;
		p3.add(maj,a);		
		
		a.gridx=10;
		a.gridy=1;
		p3.add(tnbr,a);
		
		
		
		a.gridx=10;
		a.gridy=5;
		p3.add(tmaj,a);
		
		
		
		
			calculer.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) { 
	    		int temp=0;
	   
	    		for(int j=0;j<vaccin.getRowCount();j++)
                    { 
                   if(vaccin.getValueAt(j,7).equals("OUI"))
                   {
                   	temp++;
                   	}
                  
                    }
                   tnbr.setText(String.valueOf(temp));}
	    	
		 });

			maj.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				int a=Integer.parseInt(tnbr.getText());
				int b;
				b=50-a;
				tmaj.setText(String.valueOf(b));		
				
			}
			});
		    
			
		    ajouter.addActionListener(new ActionListener() {
				
				
				public void actionPerformed(ActionEvent e) {
					
					String nom=tnom.getText();
					String prenom=tprenom.getText();
					String age=tage.getText();
					String cin=tcin.getText();
					String mal=String.valueOf(choix.getSelectedItem());
					
					row[0]=nom;
					row[1]=prenom;
					row[2]=cin;
					row[3]=age;
					row[4]=mal;
					
					model.addRow(row);
			
					
					tnom.setText("");
					tprenom.setText("");
					tage.setText("");
					tcin.setText("");
					
					
					
				}
			});
		
		    
		   
		    
		    affecter.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					int count=0;
					 for(int j=0;j<vaccin.getRowCount();j++){ 
					
						 if((vaccin.getValueAt(j,5).equals("Oui")))
						 { 
							 count ++;
							 vaccin.setValueAt(count,j,6);
						 }
						 
						 else
						 {vaccin.setValueAt("-",j,6);}
					 }
					 }
					
					
				
		    	  });
					
		    
		    
	    f.add(p1,BorderLayout.NORTH);
		f.add(p2,BorderLayout.CENTER);
		f.add(p3,BorderLayout.SOUTH);
		
		
		
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
		f.setSize(700, 500);
		f.setVisible(true);
		
	}	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Covidinterface();
	}
}
