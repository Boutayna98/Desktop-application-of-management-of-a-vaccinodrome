package projetroad;

public class Infirmier {
	
	private static final long serialVersionUID = 1L;
	private int matricule;
	private String nom;
	private String prenom;
	private String cin;
	private String num�rodet�l�phone;;
	
	public Infirmier() {
		super();
	}

	public int getMatricule() {
		return matricule;
	}

	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getcin() {
		return cin;
	}

	public void setUsername(String cin) {
		this.cin = cin;
	}

	public String getnum�rodet�l�phone() {
		return num�rodet�l�phone;
	}

	public void setnum�rodet�l�phone(String num�rodet�l�phone) {
		this.num�rodet�l�phone = num�rodet�l�phone;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}




    /**
     * Default constructor
     */
    public void infirmier() {
    }

}
