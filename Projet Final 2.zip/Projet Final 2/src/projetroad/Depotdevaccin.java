package projetroad;


	public class Depotdevaccin {
		private String iddepot;
		private String typedevaccin;
		
		
	public static void main(String[] args) {
			// TODO Auto-generated method stub

		
}
	}
