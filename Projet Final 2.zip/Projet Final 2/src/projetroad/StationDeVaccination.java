package projetroad;

public class StationDeVaccination {
	private String idstvacc;
	private String adressestvacc;
	private String nomstvacc;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


}
