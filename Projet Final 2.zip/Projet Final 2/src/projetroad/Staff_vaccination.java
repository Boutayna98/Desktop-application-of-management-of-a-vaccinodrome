package projetroad;

public class Staff_vaccination {
	private String non;
	private String pr�nom;
	private String cin;
	private String num�rodet�l�;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
public class medecin extends Staff_vaccination{
	
}
public class AgentDacceuil extends Staff_vaccination{
	
}

}
